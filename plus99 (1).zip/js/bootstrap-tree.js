$(document).ready(function () {
    $('.tree > ul').attr('role', 'tree').find('ul').attr('role', 'group');
    $('.tree').find('li:has(ul)').addClass('parent_li').attr('role', 'treeitem').find(' > span').
    attr('title', 'Collapse Account Group').on('click', function (e) {
        var children = $(this).parent('li.parent_li').find(' > ul > li');
        if (children.is(':visible')) {
            children.hide('fast');
            $(this).attr('title', 'Expand Account Group').find(' > i').
            addClass('icon-plus-sign').removeClass('icon-minus-sign');
        } else {
            children.show('fast');
            $(this).attr('title', 'Collapse Account Group').find(' > i').addClass('icon-minus-sign').
            removeClass('icon-plus-sign');
        }
        e.stopPropagation();
    });
    $('#expand').click(function () {
        $('.te').toggle('fast');
        var v=$('#expand').text();
        if(v==="Hide All") {
            $('#expand').text('Show All');
        }
            else {
            $('#expand').text('Hide All');
        }
    })

});
