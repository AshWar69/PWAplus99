<?php $__env->startComponent('mail::message'); ?>
# New Order
<!DOCTYPE html>
<html>
<head>
<style>
table, th, td {
  border: 1px solid black;
  border-collapse: collapse;
}
</style>
</head>
<body>
<h3>Your New Order Is:</h3>
<table style="width:100%">
    <thead>
        <tr>
            <th>SrNo</th>
            <th>Order_details</th>
            <th>Total Price</th>
            <th>Payment_Mode</th>
            <th>Order_Status</th>
        </tr>
    </thead>
    <tbody>
        <?php $tot=0; $i=1; ?>
        <?php $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($i); ?></td>
            <td><?php echo e($data->order_details); ?></td>
            <td>&#x20b9; <?php echo e($data->tprice); ?></td>
            <td><?php echo e($data->payment_mode); ?></td>
            <td><?php echo e($data->status); ?></td>
        </tr>
        <?php 
            $tot = $data->tprice;
            $i++;
        ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
    <tfoot>
        <tr>
            <td colspan="4"><strong>Total money to recieve:</strong></td>
            <td id="gtotal">&#x20b9; <?php echo e($tot); ?> </td>
        </tr>
    </tfoot>
</table>

</pre>
</body>
</html>

Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH /home/u806097612/domains/maqsoodi.in/public_html/store/resources/views/emails/ordermail.blade.php ENDPATH**/ ?>