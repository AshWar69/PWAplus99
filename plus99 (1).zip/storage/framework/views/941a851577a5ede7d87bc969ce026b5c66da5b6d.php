
<?php $__env->startSection('content'); ?>
    <div class="card shadow">
        <div class="card-header">
            <h3 class="card-title mb-0">Users Report</h3>
        </div><!-- end card header -->
        <div class="card-body table-responsive">
            <!-- table -->
            <table class="table align-middle mb-0 datatables" id="userRep">
                <thead class="table-light text-center">
                    <tr>
                        <th>SrNo.</th>
                        <th>Profile Pic</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Mobile</th>
                        <th>Gender</th>
                        <th>AlternateNumber</th>
                    </tr>
                </thead>
                <tbody class="text-center">
                    <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($i); ?></td>
                            <td>
                                <div class="flex-shrink-0">
                                    <img class="avatar-xs rounded-circle"
                                        src="<?php echo e(asset('images/users/' . $p->img)); ?>">
                                </div>
                            </td>
                            <td><?php echo e($p->name); ?></td>
                            <td><?php echo e($p->email); ?></td>
                            <td><?php echo e($p->mobile); ?></td>
                            <td><?php echo e($p->gender); ?></td>
                            <td><?php echo e($p->alternateNumber); ?></td>
                        </tr>
                        <?php $i++; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        $(function() {
            var table = $('#userRep').DataTable({
                processing: true,
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u806097612/domains/maqsoodi.in/public_html/store/resources/views/pages/users/users.blade.php ENDPATH**/ ?>