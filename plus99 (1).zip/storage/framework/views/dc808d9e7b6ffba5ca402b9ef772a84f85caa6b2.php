<?php echo $__env->make('includes.oheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<main class="main">
    
        <?php echo $__env->yieldContent('content'); ?>
    
</main>

<?php echo $__env->make('includes.ofooter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u806097612/domains/maqsoodi.in/public_html/store/resources/views/layouts/main.blade.php ENDPATH**/ ?>