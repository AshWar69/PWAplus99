<?php $__env->startComponent('mail::message'); ?>
# Plus99 Order
<!DOCTYPE html>
<html>
<head>
<style>
table, th, td {
  border: 1px solid black;
  border-collapse: collapse;
}
</style>
</head>
<body>
<h3>Your Order Is:</h3>
<p>Your Order Is Not Confirmed Yet By <b>ADMIN</b>. Order Is Pending, When Order Get Confirmed You Recieve Confirmation Email On Your Registered Email. </p>
<table style="width:100%">
    <thead>
        <tr>
            <th>SrNo</th>
            <th>Order_details</th>
            <th>Total Price</th>
            <th>Payment_Mode</th>
            <th>Order_Status</th>
        </tr>
    </thead>
    <tbody>
        <?php $tot=0; $i=1; ?>
        <?php $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($i); ?></td>
            <td><?php echo e($data->order_details); ?></td>
            <td>&#x20b9; <?php echo e($data->tprice); ?></td>
            <td><?php echo e($data->payment_mode); ?></td>
            <td><?php echo e($data->status); ?></td>
        </tr>
        <?php 
            $tot = $data->tprice;
            $i++;
        ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
    <tfoot>
        <tr>
            <td colspan="4"><strong>Total amount to be paid:</strong></td>
            <td id="gtotal">&#x20b9; <?php echo e($tot); ?> </td>
        </tr>
    </tfoot>
</table>

<p><b>Note:</b> Your Order Is Not Accepted Yet. When your order is accepted you will be notified through an email or by getting a confirmation call from our team.</p>
</body>
</html>

Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH /home/u806097612/domains/maqsoodi.in/public_html/store/resources/views/emails/orderconfirmmail.blade.php ENDPATH**/ ?>