
<?php $__env->startSection('content'); ?>
    <div class="page-header cph-header pl-4 pr-4" style="background-color: #fff7ec">
        <h1 class="page-title font-weight-light text-capitalize">Companies</h1>
        <div class="category-container row justify-content-center cols-2 cols-xs-3 cols-sm-4 cols-md-6 pt-6">
            <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $com): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="category category-ellipse mb-4 mb-md-0">
                    <a href="<?php echo e(URL::to('SingleCompany/' . $com->id)); ?>">
                        <figure>
                            <img src="<?php echo e(asset('images/company_images/' . $com->image)); ?>" alt="<?php echo e($com->name); ?>"
                                width="160" height="161">
                        </figure>
                    </a>
                    <div class="category-content">
                        <h3 class="category-name"><a
                                href="<?php echo e(URL::to('SingleCompany/' . $com->id)); ?>"><?php echo e($com->name); ?></a>
                        </h3>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    <section class="mt-10 pt-3 mb-10 pb-3 recommend-section">
        <div class="container-fluid">
            <h2 class="title title-line title-underline with-link text-normal mb-5">
                <span>Recommended</span>
                <a href="<?php echo e(URL::to('Shop')); ?>" class="btn btn-link text-capitalize">More
                    Products<i class="p-icon-arrow-long-right"></i></a>
            </h2>
            <div class="owl-carousel owl-theme owl-nav-inner owl-nav-arrow row cols-2 cols-md-4 cols-lg-6"
                data-owl-options="{
                                    'nav': true,
                                    'dots': false,
                                    'loop': false,
                                    'margin': 20,
                                    'responsive': {
                                        '0': {
                                            'items': 2,
                                            'nav': false
                                        },
                                        '768': {
                                            'items': 4
                                        },
                                        '992': {
                                            'items': 6
                                        }
                                    }
                                }">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="product shadow-media text-center">
                        <figure class="product-media">
                            <a href="<?php echo e(URL::to('ProductInfo/' . $pro->id)); ?>">
                                <img src="<?php echo e(asset('images/product_images/' . $pro->image)); ?>" alt="product" width="295"
                                    height="369">
                            </a>
                            <div class="product-action-vertical">
                                <a href="#" class="btn-product-icon btn-cart" data-toggle="modal"
                                    data-target="#addCartModal" title="Add to Cart">
                                    <i class="p-icon-cart-solid"></i>
                                </a>
                            </div>
                        </figure>
                        <div class="product-details">
                            <h5 class="product-name">
                                <a href="<?php echo e(URL::to('ProductInfo/' . $pro->id)); ?>">
                                    <?php echo e($pro->name); ?>

                                </a>
                            </h5>
                            <span class="product-price">
                                <span class="price">₹ <?php echo e($pro->perprice); ?></span>
                            </span>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\MyWork\laravel_prg\store99\resources\views/pages/frontend/category.blade.php ENDPATH**/ ?>