<li class="fw-medium fs-14"><span><i class="ri-add-circle-fill align-bottom"></i><?php echo e($childs->name); ?></span>
<?php if($childs->childrenRecursive): ?>
    <ul class="te">
    <?php $__currentLoopData = $childs->childrenRecursive; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo $__env->make('pages.products.agchild',['childs'=>$child], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
<?php endif; ?>
</li>
<?php /**PATH D:\MyWork\laravel_prg\store99\resources\views/pages/products/agchild.blade.php ENDPATH**/ ?>