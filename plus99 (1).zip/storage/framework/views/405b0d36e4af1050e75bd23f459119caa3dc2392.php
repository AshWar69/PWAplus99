<a class="dropdown-item" data-value="<?php echo e($childs->id); ?>" data-level="<?php echo e($level); ?>" href=""><?php if($com == $childs->id): ?> <?php echo e($childs->name); ?> <?php endif; ?></a>

<?php if($childs->childrenRecursive): ?>
    <?php $__currentLoopData = $childs->childrenRecursive; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo $__env->make('pages.products.child',['childs'=>$child, 'com'=>$com,'level'=>$level+1], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php /**PATH D:\MyWork\laravel_prg\store99\resources\views/pages/products/ecchild.blade.php ENDPATH**/ ?>