
<?php $__env->startSection('content'); ?>
    <main class="main order">
        <div class="page-content pt-8 pb-10 mb-10">
            <div class="step-by pr-4 pl-4">
                <h3 class="title title-step"><a href="cart.html">1.Shopping Cart</a></h3>
                <h3 class="title title-step"><a href="checkout.html">2.Checkout</a></h3>
                <h3 class="title title-step active"><a href="order.html">3.Order Complete</a></h3>
            </div>
            <div class="container mt-7">
                <div class="order-message">
                    <div class="icon-box d-inline-flex align-items-center">
                        <div class="icon-box-icon mb-0">
                            <svg xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
                                viewBox="0 0 50 50" enable-background="new 0 0 50 50" xml:space="preserve">
                                <g>
                                    <path fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="bevel"
                                        stroke-miterlimit="10"
                                        d="
                                                            M33.3,3.9c-2.7-1.1-5.6-1.8-8.7-1.8c-12.3,0-22.4,10-22.4,22.4c0,12.3,10,22.4,22.4,22.4c12.3,0,22.4-10,22.4-22.4
                                                            c0-0.7,0-1.4-0.1-2.1">
                                    </path>
                                    <polyline fill="none" stroke-width="3" stroke-linecap="round" stroke-linejoin="bevel"
                                        stroke-miterlimit="10"
                                        points="
                                                            48,6.9 24.4,29.8 17.2,22.3 	">
                                    </polyline>
                                </g>
                            </svg>
                        </div>
                        <h3 class="icon-box-title">Thank you. Your Order has been received.</h3>
                    </div>
                </div>
                <div class="order-results row cols-xl-6 cols-md-3 cols-sm-2 mt-10 pt-2 mb-4">
                    <div class="overview-item">
                        <span>Status</span>
                        <label>Processing</label>
                    </div>
                    <div class="overview-item">
                        <span>Date</span>
                        <label><?php echo e(date('d-m-Y' ,strtotime($order->created_at))); ?></label>
                    </div>
                    <div class="overview-item">
                        <span>Email:</span>
                        <label><?php echo e(Auth::user()->email); ?></label>
                    </div>
                    <div class="overview-item">
                        <span>Total:</span>
                        <label><?php echo e($order->tprice); ?></label>
                    </div>
                    <div class="overview-item">
                        <span>Payment method:</span>
                        <label>Cash on delivery</label>
                    </div>
                </div>
                <h2 class="detail-title mb-6">Order Details</h2>
                <div class="order-details">
                    <table class="order-details-table">
                        <thead>
                            <tr class="summary-subtotal">
                                <td>
                                    <h3 class="summary-subtitle">Your Order</h3>
                                </td>
                                <td></td>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td class="product-subtitle">Product</td>
                                <td></td>
                            </tr>
                            <tr>
                                <td class="product-name">Juice <span><i class="p-icon-times"></i> 1</span>
                                </td>
                                <td class="product-price">$129.99</td>
                            </tr>
                            <tr>
                                <td class="product-name">Greenhouse Cherry <span><i class="p-icon-times"></i>
                                        2</span></td>
                                <td class="product-price">$196.00</td>
                            </tr>
                            <tr class="summary-subtotal">
                                <td>
                                    <h4 class="summary-subtitle">Subtotal:</h4>
                                </td>
                                <td class="summary-value font-weight-normal">$325.99</td>
                            </tr>
                            <tr class="summary-subtotal">
                                <td>
                                    <h4 class="summary-subtitle">Payment method:</h4>
                                </td>
                                <td class="summary-value">Cash on delivery</td>
                            </tr>
                            <tr class="summary-subtotal">
                                <td>
                                    <h4 class="summary-subtitle">Total:</h4>
                                </td>
                                <td>
                                    <p class="summary-total-price">$325.99</p>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\MyWork\laravel_prg\store99\resources\views/pages/frontend/order.blade.php ENDPATH**/ ?>