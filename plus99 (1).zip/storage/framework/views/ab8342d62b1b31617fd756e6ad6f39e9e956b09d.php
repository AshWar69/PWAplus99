
<?php $__env->startSection('content'); ?>
    <main class="main cart">
        <div class="page-content pt-8 pb-10 mb-4">
            <div class="step-by">
                <h3 class="title title-step active"><a href="<?php echo e(URL::to('Cart')); ?>">1.Shopping Cart</a></h3>
                <h3 class="title title-step"><a href="<?php echo e(URL::to('Checkout')); ?>">2.Checkout</a></h3>
                <h3 class="title title-step"><a href="<?php echo e(URL::to('#')); ?>">3.Order Complete</a></h3>
            </div>
            <div class="container mt-7 mb-2">
                <div class="row">
                    <?php if(Auth::user()): ?>
                        <div class="col-lg-8 col-md-12 pr-lg-6">
                            <table class="shop-table cart-table">
                                <thead>
                                    <tr>
                                        <th><span>Product</span></th>
                                        <th></th>
                                        <th><span>Price</span></th>
                                        <th><span>quantity</span></th>
                                        <th>Subtotal</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $sub = 0; ?>
                                    <?php $__currentLoopData = $cartDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="product-thumbnail">
                                                <figure>
                                                    <a href="#">
                                                        <img src="<?php echo e(asset('images/product_images/' . $details->image)); ?>"
                                                            width="90" height="112" alt="<?php echo e($details->pname); ?>">
                                                    </a>
                                                </figure>
                                            </td>
                                            <td class="product-name">
                                                <div class="product-name-section">
                                                    <a href="#"><?php echo e($details->pname); ?></a>

                                                </div>
                                            </td>
                                            <td class="product-subtotal">
                                                <span class="amount">₹<?php echo e($details->price); ?> x<?php echo e($details->pquan); ?>pcs</span>
                                            </td>
                                            <td>
                                                <div class="product-quantity">
                                                    <form class="cart_upd">
                                                        <div class="input-group">
                                                            <button
                                                                class="quantity-left-minus p-icon-minus-solid qtybtn"></button>
                                                            <input type="text" name="quantity[]"
                                                                class="form-control input-number" style="width: 40px;"
                                                                value="<?php echo e($details->quan); ?>" min="1" max="100">
                                                            <input type="hidden" name="cart[]"
                                                                value="<?php echo e($details->cid); ?>">
                                                            <button
                                                                class="quantity-right-plus p-icon-plus-solid qtybtn"></button>
                                                        </div>
                                                    </form>
                                                </div>
                                                <!-- <span class="quan">x</span> -->
                                            </td>
                                            <td class="product-price">
                                                <span
                                                    class="amount">₹<?php echo e($details->quan * $details->pquan * $details->price); ?></span>
                                            </td>
                                            <td class="product-remove">
                                                <a href="#" class="btn-remove" id="<?php echo e($details->cid); ?>"
                                                    title="Remove this product">
                                                    <i class="p-icon-times"></i>
                                                </a>
                                            </td>
                                        </tr>
                                        <?php $sub += ($details->quan*$details->pquan)*$details->price; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <div class="cart-actions mb-6 pt-6">
                                <a href="shop.php" class="btn btn-dim btn-icon-left mr-4 mb-4"><i
                                        class="p-icon-arrow-long-left"></i>Continue Shopping</a>
                            </div>
                            
                        </div>
                        <aside class="col-lg-4 sticky-sidebar-wrapper">
                            <div class="sticky-sidebar" data-sticky-options="{'bottom': 20}">
                                <div class="summary mb-4">
                                    <h3 class="summary-title">Cart Totals</h3>
                                    <table class="shipping mb-2">
                                        <tr class="summary-subtotal">
                                            <td>
                                                <h4 class="summary-subtitle">Subtotal</h4>
                                            </td>
                                            <td>
                                                <p class="summary-subtotal-price">₹<?php echo e($sub); ?></p>
                                            </td>
                                        </tr>
                                    </table>
                                    <a href="<?php echo e(URL::to('Checkout')); ?>" class="btn btn-dim btn-checkout btn-block">Proceed
                                        to
                                        checkout</a>
                                </div>
                            </div>
                        </aside>
                    <?php else: ?>
                        <h1 class='text-center'>Cart Empty</h1>;
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        $('.btn-remove').click(function(e) {
            e.preventDefault();
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            var id = $(this).attr('id');

            $.ajax({
                type: "POST",
                url: "<?php echo e(route('DelCartItem')); ?>",
                data: "rid=" + id,
                success: function(response) {
                    setTimeout(function() {
                        location.reload();
                    }, 2000);
                },
                error: function(response) {
                    setTimeout(function() {
                        location.reload();
                    }, 2000);
                }
            });
        });

        var proQty = $('.input-group');
        proQty.on('click', '.qtybtn', function(e) {
            var $button = $(this);
            var oldValue = $button.parent().find("input[name='quantity[]']").val();
            if ($button.hasClass('quantity-right-plus')) {
                var newVal = parseInt(oldValue) + 1;
            } else if ($button.hasClass('quantity-left-minus')) {
                // Don't allow decrementing below zero
                if (oldValue == 1) {
                    var newVal = parseInt(oldValue);
                } else {
                    var newVal = parseInt(oldValue) - 1;
                }
            }
            if ($button.parent().find("input[name='quantity[]']").val(newVal)) {
                e.preventDefault();
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });

                $.ajax({
                    type: "POST",
                    url: "<?php echo e(route('updateCart')); ?>",
                    data: $('.cart_upd').serialize(),

                    success: function(response) {
                        setTimeout(function() {
                            location.reload();
                        }, 2000);
                    },
                    error: function(response) {
                        setTimeout(function() {
                            location.reload();
                        }, 2000);
                    }
                });
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u806097612/domains/maqsoodi.in/public_html/store/resources/views/pages/frontend/cart.blade.php ENDPATH**/ ?>