
<?php $__env->startSection('content'); ?>

<h1>DashBoard</h1>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u806097612/domains/maqsoodi.in/public_html/store/resources/views/pages/index.blade.php ENDPATH**/ ?>