
<?php $__env->startSection('content'); ?>

<div class="page-header" style="background-color: #f9f8f4">
    <h1 class="page-title py-0 my-0">Our Products</h1>
</div>
<div class="page-content mb-10 shop-page">
    <div class="container">
        <div class="row main-content-wrap">
            <div class="col-lg-12 main-content">
                <nav class="toolbox sticky-toolbox sticky-content fix-top">
                    <div class="toolbox-left">
                        <a href="#" class="toolbox-item left-sidebar-toggle btn btn-outline btn-primary btn-icon-right d-lg-none"><span>Filter</span><i class="p-icon-category-1 ml-md-1"></i></a>
                        <div class="toolbox-item toolbox-sort select-menu">
                            <label>Sort By :</label>
                            <select name="orderby">
                                <option value="default" selected="selected">Default Sorting</option>
                                <option value="popularity">Sort By Popularity</option>
                                <option value="rating">Sort By The Latest</option>
                                <option value="date">Sort By Average Rating</option>
                                <option value="price-low">Sort By Price: Low To High</option>
                                <option value="price-high">Sort By Price: High To Low</option>
                            </select>
                        </div>
                    </div>
                    <div class="toolbox-right">
                        <div class="toolbox-item toolbox-show select-box">
                            <label>Show :</label>
                            <select name="count">
                                <option value="12">12</option>
                                <option value="24">24</option>
                                <option value="36">36</option>
                            </select>
                        </div>
                        <div class="toolbox-item toolbox-layout">
                            <a href="shop-list.html" class="p-icon-list btn-layout active"></a>
                            <a href="shop-3-cols.html" class="p-icon-grid btn-layout"></a>
                        </div>
                    </div>
                </nav>
                <div class="row product-wrapper cols-lg-4 cols-2">
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="product-wrap">
                        <div class="product shadow-media text-center">
                            <figure class="product-media">
                                <a href="<?php echo e(URL::to('ProductInfo/'.$pro->id)); ?>">
                                    <img src="<?php echo e(asset('images/product_images/'.$pro->image)); ?>" alt="<?php echo e($pro->name); ?>" width="295" height="369" />
                                </a>
                                
                            </figure>
                            <div class="product-details">
                                <h5 class="product-name">
                                    <a href="<?php echo e(URL::to('ProductInfo/'.$pro->id)); ?>">
                                        <?php echo e($pro->name); ?>

                                    </a>
                                </h5>
                                <span class="product-price">
                                    <ins class="new-price">₹<?php echo e($pro->perprice); ?></ins>
                                </span>
                            </div>
                        </div>
                        <!-- End .product -->
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>\
            </div>
        </div>
    </div>
</div>    

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\MyWork\laravel_prg\store99\resources\views/pages/frontend/product.blade.php ENDPATH**/ ?>