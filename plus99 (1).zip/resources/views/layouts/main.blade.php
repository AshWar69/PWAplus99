@include('includes.oheader')

<main class="main">
    {{-- <div class="page-content"> --}}
        @yield('content')
    {{-- </div> --}}
</main>

@include('includes.ofooter')