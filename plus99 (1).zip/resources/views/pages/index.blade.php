@extends('layouts.index')
@section('content')

<h1>DashBoard</h1>

@endsection